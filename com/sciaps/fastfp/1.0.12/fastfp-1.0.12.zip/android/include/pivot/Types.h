#ifndef PIVOT_TYPES_H
#define PIVOT_TYPES_H

namespace pivot {

typedef uint8_t byte;

} // namespace pivot

#endif // PIVOT_TYPES_H
