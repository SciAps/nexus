#ifndef PIVOT_CONFIG_H
#define PIVOT_CONFIG_H

#define Pivot_VERSION_MAJOR 1
#define Pivot_VERSION_MINOR 0



///////////////////////////////////////////

#ifndef NULL
#define NULL 0
#endif


#endif // PIVOT_CONFIG_H
