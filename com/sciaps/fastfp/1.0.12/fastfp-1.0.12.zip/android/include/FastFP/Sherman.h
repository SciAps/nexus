#ifndef FASTFP_SHERMAN_H
#define FASTFP_SHERMAN_H

namespace fastfp {

class Sherman {
public:

  class Chemistry {
  public:
    Chemistry(const std::set<Element>&);

    inline size_t size() const;

    inline const Element* elements() const;
    
    inline const fp_float* weightFrac() const;
    inline fp_float* weightFrac();
    
    inline const fp_float* weightUncer() const;
    inline fp_float* weightUncer();

    bool set(Element, fp_float, fp_float error = 0.0);

    int getIndex(Element) const;
    bool hasElement(Element) const;
    fp_float& weightFracFor(Element);
    fp_float& uncertFor(Element);

    void setCompound(const Compound&);
    Compound getCompound();

  private:
    std::vector<Element> mElements;
    std::vector<fp_float> mWtFrac;
    std::vector<fp_float> mWtError;
  };

  struct Line {
    const XRFLine line;
    const fp_float sensitivity;
    fp_float& weightFrac;
    fp_float& weightErr;
    fp_float predictedRate;

    Line(const XRFLine&, fp_float, fp_float&, fp_float&);
  };

  class Builder {
  public:
    Builder(const sp<Chemistry>&, const sp<Spectrum>& spectrum);

    void takeOffAngle(Angle);
    void incidenceAngle(Angle);

    /**
     * @brief add all XRF lines associated with element
     * @param e
     * @param usePhysical true if using obsolete Siegbahn lines
     */
    void addAllLinesFromElement(Element e, bool usePhysical);

    void addXRFLine(const XRFLine& line);


    status_t create(Sherman&);


  private:
    sp<Chemistry> mChemistry;
    sp<Spectrum> mExcitationSpectrum;
    std::set<XRFLine> mXRFLines;
    Angle mTakeoffAngle;
    Angle mIncidenceAngle;

  };

  ~Sherman();

  const Angle& takeOffAngle() const;
  const Angle& incidenceAngle() const;
  const Spectrum& excitationSpectrum() const;

  Chemistry& chemistry();
  status_t computeRates();
  inline vector_view<Sherman::Line> getLines();
  inline const std::vector<Line> lines() const;


private:
  sp<Chemistry> mChemistry;

  size_t mNumExcitationEnergies;
  fp_float secondaryFluorescense(size_t linei, size_t linej, size_t iEng);

  //return total absorption cross section for the line/excitation index.
  fp_float totalCS(size_t line, size_t energy);

  //return only the photoionization cross section for line/excitation index
  fp_float photoCS(size_t line, size_t energy);

  Angle mTakeoffAngle;
  Angle mIncidenceAngle;

  sp<Spectrum> mExcitationSpectrum;

  //organize by line index
  std::vector<Line> mLines;
  std::vector<fp_float> mLineTotalAttenuations;

  //organized by excitation index
  std::vector<fp_float> mExcitationTotalAttenuations;

  //organized by line/line
  std::vector< std::vector<fp_float> > mPEAFluor;




#ifdef PRECALCULATE
  ////////////// Static pre-calcuated values not dependant on chemistry ////////////////
  // photoelectric absorption for each element for each excitation energy.
  const fp_float* mPEAForLineEnergy;

#endif // PRECALCULATE



};

/******************* INLINE METHODS *********************/
/********************************************************/

inline size_t Sherman::Chemistry::size() const {
  return mElements.size();
}

inline const Element* Sherman::Chemistry::elements() const {
  return mElements.data();
}

inline const fp_float* Sherman::Chemistry::weightFrac() const {
  return mWtFrac.data();
}

inline fp_float* Sherman::Chemistry::weightFrac() {
  return mWtFrac.data();
}

inline fp_float& Sherman::Chemistry::weightFracFor(Element e) {
  return mWtFrac[getIndex(e)];
}

inline fp_float& Sherman::Chemistry::uncertFor(Element e) {
  return mWtError[getIndex(e)];
}

inline const fp_float* Sherman::Chemistry::weightUncer() const {
  return mWtError.data();
}

inline fp_float* Sherman::Chemistry::weightUncer() {
  return mWtError.data();
}

inline vector_view<Sherman::Line> Sherman::getLines() {
  return vector_view<Sherman::Line>(mLines);
}

inline Sherman::Chemistry& Sherman::chemistry() {
  return *mChemistry;
}

inline const std::vector<Sherman::Line> Sherman::lines() const {
  return mLines;
}

} // namespace fastfp

#endif // FASTFP_SHERMAN_H
