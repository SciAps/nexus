#ifndef FASTFP_FPRATEALGORITHM_H
#define FASTFP_FPRATEALGORITHM_H

#include <json/json.h>

namespace fastfp
{
    class FPRateAlgorithm
    {
    public:
        struct LineKey
        {
            const size_t beam;
            const XRFLine line;
            
            LineKey(size_t beam, const XRFLine& line);
            
            bool operator<(const LineKey& o) const;
            bool operator==(const LineKey& o) const;
            bool operator!=(const LineKey& o) const;
        };
        
        class Standard
        {
        public:
            Standard();
            
            void setName(const char*);
            const char* name() const;
            Compound compound;
            std::map<LineKey, fp_float> rates;
            fp_float LERate;
            
            bool hasLine(const LineKey&) const;
            
        private:
            std::string mName;
        };
        
        struct AnalysisLine
        {
            const LineKey lineKey;
            fp_float& wtFrac;
            fp_float& wtUncert;
            
            fp_float measuredRate;
            fp_float measuredRateUncert;
            fp_float normalizedMeasuredRate;
            
            const fp_float& predictedRate;
            fp_float normalizedPredictedRate;
            
            fp_float calibrationFactor;
            
            fp_float initFactor;
            
            bool inUse;  // whether this line has a measured rate and should be used in calculation
            
            bool operator<(const AnalysisLine&) const;
            
            AnalysisLine(size_t beam, Sherman::Line& line);
        };
        
        class Builder
        {
        public:
            class Beam
            {
                friend class Builder;
            
            public:
                static status_t readBeam(const Json::Value&, up<FPRateAlgorithm::Builder::Beam>&);
                
                Beam(float keV);
                
                void tubeFilters(const std::vector<Filter>&);
                
                /**
                 * @brief add an element for analysis (will not actually add a line)
                 */
                void addElement(Element e);
                
                /**
                 * @brief add all XRF lines associated with element
                 * @param e
                 * @param usePhysical true if using obsolete Siegbahn lines
                 */
                void addAllLinesFromElement(Element e, bool usePhysical);
                
                /**
                 * @brief add an element to the "LE basket"
                 * @param e
                 */
                void addLEelement(Element e);
                
                /**
                 * @brief set the energy at which the compton rate is measured
                 * @param keV energy at which the compton the compton rate is measured
                 */
                void setLEEnergyKeV(fp_float keV);
                
                void addLine(const XRFLine& line);
                
            protected:
                float mTubeVoltageKeV;
                std::vector<Filter> mTubeFilters;
                std::set<Element> mElements;
                std::set<Element> mLEElements;
                std::set<XRFLine> mLines;
                fp_float mLEEnergyKeV;
            };
            
            Builder();
            status_t readConfig(const char* configFilepath);
            status_t readConfig(const Json::Value&);
            void tubeHardware(const TubeHardware&);
            void geometry(Angle takeOff, Angle insidence);
            void detectorHardware(const DetectorHardware&);
            
            void addBeam(const Beam&);
            
            status_t create(up<FPRateAlgorithm>&);
            
        private:
            TubeHardware mTubeHardware;
            Angle mTakeoffAngle;
            Angle mIncidenceAngle;
            DetectorHardware mDetectorHardware;
            std::vector<Beam> mBeams;
        };
        
        class Calibration
        {
        public:
            Calibration(FPRateAlgorithm&);
            
            void addStandard(const Standard& standard);
            void computeCalibrationFactors();
            
        private:
            FPRateAlgorithm& mAlgorithm;
            std::vector<Standard> mStandards;
            
            typedef std::set<FPRateAlgorithm::AnalysisLine*, bool(*)(const FPRateAlgorithm::AnalysisLine*, const FPRateAlgorithm::AnalysisLine*)> AnalysisLineSet;
            
            void computeCalibrationSet(AnalysisLineSet&, std::set<Element>&);
            void doLECalibration();
            Compound createBeamCompound(const Compound&, const std::set<Element>&);
        };
        
        class RateMapper
        {
        public:
            RateMapper(FPRateAlgorithm&, size_t beam, const std::vector<XRFLine>&);
            
            template<typename FT>
            void setRates(FT comptonRate, FT* values, FT* uncertValues = NULL);
            
        private:
            FPRateAlgorithm& mAlgorithm;
            const size_t mBeam;
            //map incoming index ==> mAlogrithm.mAnalysisLines index
            std::vector<int> mIndexMap;
        };
        
        status_t writeCalibrationFile(const char* filepath);
        status_t readCalibrationFile(const char* filepath);
        
        inline size_t numBeams() const;
        inline std::vector<AnalysisLine>& getLines();
        void setAllLinesNotInUse();
        void setLERate(size_t beam, fp_float);
        void setLECalibrationFactor(size_t beam, fp_float);
        void setLECalibrationOffset(size_t beam, fp_float);
        void setRates();
        void doInitialGuess(size_t beam = 0);
        
        /**
         * @breif
         */
        void process(int beam = -1);
        Compound getCompound() const;
        
        inline Sherman& getSherman(size_t beam);
        inline DetectorHardware& getDetectorHardware();
        
    private:
        DetectorHardware mDetectorHardware;
        sp<Sherman::Chemistry> mChemistry;
        std::vector<Sherman> mShermanBeams;
        
        std::vector< std::set<Element> > mLEElements;
        std::vector<fp_float> mLEMeasuredRates;
        std::vector<fp_float> mLEEnergyKeVs;
        std::vector<fp_float> mLEFactors;
        std::vector<fp_float> mLEOffsets;
        
        //organized by line
        std::vector<AnalysisLine> mAnalysisLines;
        
        AnalysisLine* findLine(size_t beam, const XRFLine& line);
        fp_float getComptonRateForBeam(size_t beam);
        void normalizeBeamChem(size_t beam);
        
        void adjustChemByRatio();
        void adjustChemByResidual(int beam);
        void normalizeAllChem();
        void setLEAsBalance();
        void adjustLEChem(size_t beam, fp_float normalizedPredictedLERate, fp_float);
        void adjustLEChemByRatio();
        void adjustLEChemByResidual(int beam);
        
        inline vector_view<FPRateAlgorithm::AnalysisLine> getLinesForBeam(size_t beam);
    };
    
    inline size_t FPRateAlgorithm::numBeams() const
    {
        return mShermanBeams.size();
    }
    
    inline std::vector<FPRateAlgorithm::AnalysisLine>& FPRateAlgorithm::getLines()
    {
        return mAnalysisLines;
    }
    
    inline vector_view<FPRateAlgorithm::AnalysisLine> FPRateAlgorithm::getLinesForBeam(size_t beam)
    {
        std::vector<FPRateAlgorithm::AnalysisLine>::iterator begin;
        std::vector<FPRateAlgorithm::AnalysisLine>::iterator end = mAnalysisLines.end();;
        
        for (std::vector<FPRateAlgorithm::AnalysisLine>::iterator it=mAnalysisLines.begin(); it!=mAnalysisLines.end(); it++)
        {
            if ((*it).lineKey.beam == beam)
            {
                begin = it;
                break;
            }
        }
        
        for (std::vector<FPRateAlgorithm::AnalysisLine>::iterator it=mAnalysisLines.begin(); it!=mAnalysisLines.end(); it++)
        {
            if ((*it).lineKey.beam == beam+1)
            {
                end = it;
                break;
            }
        }
        
        return vector_view<FPRateAlgorithm::AnalysisLine>(begin, end);
    }
    
    inline Sherman& FPRateAlgorithm::getSherman(size_t beam)
    {
        return mShermanBeams[beam];
    }
    
    inline DetectorHardware& FPRateAlgorithm::getDetectorHardware()
    {
        return mDetectorHardware;
    }
} // namespace fastfp

#endif // FASTFP_FPRATEALGORITHM_H
