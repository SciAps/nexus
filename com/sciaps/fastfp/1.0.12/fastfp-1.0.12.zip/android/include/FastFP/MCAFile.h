#ifndef FASTFP_MCAFILE_H
#define FASTFP_MCAFILE_H

namespace fastfp {

class MCAFile {
public:

  static status_t load(const std::string& filepath, MCAFile& retval);

  const sp<LSpectrum> getSpectrum() const;
  const std::map<std::string, std::string>& getMetadata() const;
  fp_float getLivetime() const;

  void setSpectrum(const LSpectrum& spectrum);
  void setMetadata(const std::string& key, const std::string& value);

  void write(const std::string& filepath) const;

private:
  sp<LSpectrum> mSpectrum;
  std::map<std::string, std::string> mMetadata;

};

} // namespace

#endif // FASTFP_MCAFILE_H
