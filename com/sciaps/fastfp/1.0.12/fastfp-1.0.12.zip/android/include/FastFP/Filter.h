#ifndef FASTFP_FILTER_H
#define FASTFP_FILTER_H

namespace fastfp {


/**
 * @brief return the linear attenuation coefficient for a given material / energy
 * @param Z atomic number
 * @param thickness tickness in microns
 * @param density density in g/cm^3
 * @param energy photo energy in KeV
 * @return
 */
double filterTransmission(int Z, double thickness, double density, double energy);


/**
 * @brief return the linear attenuation coefficient for a given pure element at room temperature
 * @param Z atomic number
 * @param thickness tickness in microns
 * @param density density in g/cm^3
 * @param energy photo energy in KeV
 * @return
 */
double filterTransmission(int Z, double thickness, double energy);


} // namespace fastfp

#endif // FASTFP_FILTER_H
