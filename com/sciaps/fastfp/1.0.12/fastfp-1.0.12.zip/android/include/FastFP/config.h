#ifndef FASTFP_CONFIG_H
#define FASTFP_CONFIG_H

// The floating point type used in the FastFP library
#define FASTFP_FLOATTYPE double

// using OpenMP
#define HAVE_OPENMP 1

namespace fastfp {

typedef FASTFP_FLOATTYPE fp_float;

} //namespace fastfp

#define PRECALCULATE

#endif // FASTFP_CONFIG_H
