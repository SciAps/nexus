#ifndef FASTFP_FPCOMPLETE_H
#define FASTFP_FPCOMPLETE_H

#include <FastFP/OptimizationProblem.h>

namespace fastfp {

class FPComplete {
public:
  class Builder {
  public:
    Builder();
    void tubeHardware(const TubeHardware&);
    void tubeFilters(const std::vector<Filter>&);
    void tubeVoltage(float keV);
    void elementSet(const std::set<int>& atomicNum);
    void numMCABins(size_t);
    void geometry(Angle takeOff, Angle insidenceDegrees);
    void detectorHardware(const DetectorHardware&);
    status_t create(FPComplete& retval);

  private:
    TubeHardware mTubeHardware;
    std::vector<Filter> mTubeFilters;
    float mTubeVoltageKV;
    std::set<int> mAtomicNums;
    size_t mNumMCABins;
    Angle mTakeoffAngle;
    Angle mIncidenceAngle;
    DetectorHardware mDetectorHardware;

  };

  FPComplete();
  ~FPComplete();

  void setSpectraPoint(size_t i, float x, float y);
  status_t setSpectra(const Spectrum&);
  void process();


private:
  std::vector<float> mX;
  std::vector<float> mY;
  Sherman mSherman;
  OptimizationProblem* mOptimizationProblem;


};

} // namespace fastfp

#endif // FASTFP_FPCOMPLETE_H
