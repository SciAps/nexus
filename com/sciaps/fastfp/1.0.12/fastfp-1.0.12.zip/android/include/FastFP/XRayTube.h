#ifndef FASTFP_XRAYTUBE_H
#define FASTFP_XRAYTUBE_H

namespace fastfp {

class TubeHardware {
public:
  TubeHardware() {};
  ~TubeHardware() {};

  Angle takeoffAngle;
  int windowZ;
  double windowThickness; // microns
  int anodeZ;
  double anodeThickness; // microns
};



class TubeSpectrumCreator {
public:
  TubeSpectrumCreator();

  void setHardware(const TubeHardware&);
  void setFilters(const std::vector<Filter>&);
  void setVoltage(double voltageKeV);
  double getVoltage() const;
  void setStepSize(double stepSize);

  void generateContinuumSpectrum(const double widthKeV, Spectrum&);

  DSpectrum generateDiscreteSpectrum();

  sp<Spectrum> generateTotalSpectrum();

private:
  TubeHardware mHardware;
  std::vector<Filter> mFilters;
  double mVoltage; // keV
  double mStepSize;
  
  void generateContinuumSpectrumImpl(const double widthKeV, Spectrum& spectrum);

};


} // namespace fastfp


#endif // FASTFP_XRAYTUBE_H
