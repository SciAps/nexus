#ifndef FASTFP_SHARED_BUFFER_H
#define FASTFP_SHARED_BUFFER_H

namespace fastfp {

class SharedBuffer {
public:

  enum {
    eKeepStorage = 0x00000001
  };

  static SharedBuffer* alloc(size_t size);

  inline const void* data() const;
  inline void* data();

  SharedBuffer* edit() const;

  inline size_t size() const;

  void acquire() const;

  // release a reference on this buffer, with the option of not
  // freeing the memory if it was the last reference.
  // returns previous reference count.
  int32_t release(uint32_t flags = 0) const;

  inline bool onlyOwner() const;

private:
  inline SharedBuffer() {}
  inline ~SharedBuffer() {}
  SharedBuffer(const SharedBuffer&);
  SharedBuffer& operator = (const SharedBuffer&);

  std::atomic<int> mRefs;
  size_t mSize;

};

const void* SharedBuffer::data() const {
  return this + 1;
}

void* SharedBuffer::data() {
  return this + 1;
}

size_t SharedBuffer::size() const {
  return mSize;
}

bool SharedBuffer::onlyOwner() const {
  return (mRefs == 1);
}

} // namespace fastfp


#endif // FASTFP_SHARED_BUFFER_H
