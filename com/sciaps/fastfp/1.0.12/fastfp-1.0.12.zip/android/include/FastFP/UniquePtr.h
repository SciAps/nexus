#ifndef FASTFP_UNIQUE_PTR_H
#define FASTFP_UNIQUE_PTR_H

namespace fastfp {

template <typename T>
struct DefaultDelete {
  enum { type_must_be_complete = sizeof(T) };
  DefaultDelete() {}
  void operator()(T* ptr) const {
    delete ptr;
  }
};

template <typename T>
struct DefaultDelete<T[]> {
  enum { type_must_be_complete = sizeof(T) };
  void operator()(T* ptr) const {
    delete[] ptr;
  }
};

template <typename T, typename D = DefaultDelete<T> >
class UniquePtr {
public:

  explicit UniquePtr(T* ptr = NULL)
    : mPtr(ptr) {}

  ~UniquePtr() {
    reset();
  }

  T& operator*() const {
    return *mPtr;
  }

  T* operator->() const {
    return mPtr;
  }

  T* get() const {
    return mPtr;
  }

  /* Returns the raw pointer and hands over ownership to the caller
  *  The pointer will not be deleted by UniquePtr
  */
  T* release() __attribute__((warn_unused_result)) {
    T* result = mPtr;
    mPtr = NULL;
    return result;
  }

  /* Take ownership of a given raw pointer
  *  if this UniquePtr previously owned a different raw pointer,
  *  that pointer will be freed
  */
  void reset(T* ptr = NULL) {
    if(ptr != mPtr) {
      D()(mPtr);
      mPtr = ptr;
    }
  }

private:
  T* mPtr;

  // Disallow copy and assignment
  UniquePtr(const UniquePtr&);
  void operator=(const UniquePtr&);

  // cannot compare unique pointers because they are unique
  template <typename T2> bool operator==(const UniquePtr<T2>& p) const;
  template <typename T2> bool operator!=(const UniquePtr<T2>& p) const;

};


// Partial specialization for array types.
// remove operator* and operator-> but adds operator[]
template <typename T, typename D>
class UniquePtr<T[], D> {
  explicit UniquePtr(T* ptr = NULL)
    : mPtr(ptr) {}

  ~UniquePtr() {
    reset();
  }

  T& operator[](size_t i) const {
    return mPtr[i];
  }

  T* get() const {
    return mPtr;
  }

  T* release() __attribute__((warn_unused_result)) {
    T* result = mPtr;
    mPtr = NULL;
    return result;
  }

  void reset(T* ptr = NULL) {
    if(ptr != mPtr) {
      D()(mPtr);
      mPtr = ptr;
    }
  }

private:
  T* mPtr;

// Disallow copy and assignment
  UniquePtr(const UniquePtr&);
  void operator=(const UniquePtr&);

};

} // namespace fastfp

#endif // FASTFP_UNIQUE_PTR_H
