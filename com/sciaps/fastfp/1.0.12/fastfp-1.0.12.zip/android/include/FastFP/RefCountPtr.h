#ifndef FASTFP_REFCOUNTPTR_H
#define FASTFP_REFCOUNTPTR_H

namespace fastfp {

template < typename T, typename D = DefaultDelete<T> >
class RefBase {
public:
  RefBase(T* ptr)
    : mRefs(1), mPtr(ptr) { }

  void incRef() {
    fastfp_atomic_inc(&mRefs);
  }

  void decRef() {
    if(fastfp_atomic_dec(&mRefs) == 1) {
      D(mPtr);
      delete this;
    }
  }

  T* get() const {
    return mPtr;
  }

private:
  RefBase(const RefBase&);

  mutable volatile int32_t mRefs;
  T* mPtr;
};

template <typename T>
class sp {
public:
  sp(T* ptr = NULL) {
    if(ptr) {
      mRefBase = new RefBase<T>(ptr);
    } else {
      mRefBase = NULL;
    }
  }

  sp(const sp& copy)
    : mRefBase(copy.mRefBase) {
    if(mRefBase) {
      mRefBase->incRef();
    }
  }

  template<typename U>
  sp(const sp<U>& copy)
    : mRefBase((RefBase<T>*)copy.mRefBase) {
    if(mRefBase) {
      mRefBase->incRef();
    }
  }

  ~sp() {
    if(mRefBase) {
      mRefBase->decRef();
    }
  }

  T& operator*() const {
    return *(mRefBase->get());
  }

  T* operator->() const {
    if(mRefBase) {
      return mRefBase->get();
    } else {
      return NULL;
    }
  }


private:
  template<typename Y> friend class sp;
  RefBase<T>* mRefBase;
};


} // namespace fastfp

#endif // FASTFP_REFCOUNTPTR_H
