#ifndef FASTFP_LOGGER_H
#define FASTFP_LOGGER_H

#include <spdlog/spdlog.h>

namespace fastfp {

extern spdlog::logger* getLogger();

} // namespace fastfp

#define TP_STR_HELPER(x) #x
#define TP_STR(x) TP_STR_HELPER(x)
#define LOGI(format, ...) getLogger()->info("[" __FILE__ ":" TP_STR(__LINE__) "] " format, ##__VA_ARGS__ )
#define LOGW(format, ...) getLogger()->warn("[" __FILE__ ":" TP_STR(__LINE__) "] " format, ##__VA_ARGS__ )
#define LOGE(format, ...) getLogger()->error("[" __FILE__ ":" TP_STR(__LINE__) "] " format, ##__VA_ARGS__ )

#endif // FASTFP_LOGGER_H
