#ifndef FASTFP_FASTFP_H
#define FASTFP_FASTFP_H

#include <stdint.h>
#include <stddef.h>

#include <cstdlib> // For NULL.
#include <cmath>
#include <cstring>
#include <vector>
#include <map>
#include <set>
#include <memory>
#include <iostream>
#include <fstream>

#define sp std::shared_ptr
#define wp std::weak_ptr
#define up std::unique_ptr

#include <pivot/Pivot.h>
#include <pivot/Optional.h>

#include <FastFP/Iterators.h>
#include <FastFP/config.h>
#include <FastFP/Logger.h>
#include <FastFP/SharedBuffer.h>
#include <FastFP/Common.h>
#include <FastFP/Spectrum.h>
#include <FastFP/Filter.h>
#include <FastFP/XRayTube.h>
#include <FastFP/Sherman.h>

#endif // FASTFP_FASTFP_H
