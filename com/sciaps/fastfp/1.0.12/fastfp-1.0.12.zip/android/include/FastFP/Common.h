#ifndef FASTFP_COMMON_H
#define FASTFP_COMMON_H

#include <xraylib.h>

namespace fastfp {

template<class T>
bool contains(const std::set<T>& container, const T& key) {
  return container.find(key) != container.end();
}

template<class T>
bool contains(const std::vector<T>& container, const T& key) {
  return container.find(key) != container.end();
}

enum Status {
  OK = 0,
  UNKNOWN_ERROR
};

typedef Status status_t;

const std::vector<int> ALL_PHYSICAL_LINES = {
  KA1_LINE,
  KA2_LINE,
  KA3_LINE,
  KB1_LINE,
  KB2_LINE,
  KB3_LINE,
  LA1_LINE,
  LA2_LINE,
  LB1_LINE,
  LB2_LINE,
  LG1_LINE
};

const std::vector<int> ALL_OBSOLETE_LINES = {
  KA_LINE,
  KB_LINE,
  LA_LINE,
  LB_LINE

};

class Angle {
public:
  static Angle createFromRadian(fp_float radian);
  static Angle createFromDegrees(fp_float radian);

  fp_float getRadians() const;
  fp_float getDegrees() const;

  Angle operator+ (const Angle&) const;
  operator fp_float() const;


private:
  fp_float mRadians;

};

class Element {
public:
  Element();
  Element(int Z);
  Element(const char*);

  int atomicNum() const;
  const char* symbol() const;
  bool operator< (const Element&) const;
  bool operator== (const Element&) const;
  bool operator!= (const Element&) const;
  operator int() const;

private:
  int mAtomicNum;
};

class ElementChemistry {
public:
  ElementChemistry(const Element, fp_float wtFrac = 0, fp_float wtError = 0);

  fp_float wtFrac;
  fp_float wtErr;

  const Element& element() const;
  bool operator< (const ElementChemistry&) const;

private:
  Element mElement;
};

class Compound {
public:
  Compound();
  Compound(const compoundData&);
  static Compound createPure(int Z);

  size_t size() const;
  std::set<ElementChemistry>::const_iterator begin() const;
  std::set<ElementChemistry>::const_iterator end() const;

  void set(const ElementChemistry&);


private:
  std::set<ElementChemistry> mChemValues;
};

class Filter {
public:

  /**
   * @brief create a filter of pure material
   * @param e element
   * @param thickness thickness of filter in microns
   * @param density density of material in g/cm^3. Omit or set to 0 to use density at room temperature
   * @return
   */
  static Filter create(Element e, double thickness, double density=0);


  /**
  * @brief create a filter
  * @param c
  * @param thickness thickness of filter in microns
  * @param density density of material in g/cm^3. Omit or set to 0 to use density at room temperature
  * @return
  */
  static Filter create(const Compound& c, double thickness, double density=0);

  const Compound& getCompound() const;
  double getThickness() const;
  double getDensity() const;

  double getTransmissionCoef(double energy) const;

  static double getTransmissionCoef(double energy, const std::vector<Filter>&);

private:
  Compound mCompound;
  double mThickness;
  double mDensity;

};

class XRFLine {
public:

  //XRAYLIB line-type macro
  static XRFLine create(Element Z, int line);

  Element element() const;
  int line() const; // the XRAYLIB line-type
  int shell() const; // the XRAYLIB shell-type
  fp_float lineEnergyKeV() const;
  fp_float edgeEnergyKeV() const;

  bool operator== (const XRFLine&) const;
  bool operator!= (const XRFLine&) const;
  bool operator< (const XRFLine&) const;

  // check if the Z/line-type combo is valid
  bool isValid() const;

private:
  Element mElement;
  int mLine;
  int mShell;
  fp_float mLineEnergyKeV;
  fp_float mEdgeEnergyKeV;

};

class XRFLineRate {
public:
  inline XRFLineRate(const XRFLine&, fp_float rate = 0.0, fp_float rateErr = 0.0);

  const XRFLine line;
  fp_float rate;
  fp_float rateErr;
  
  inline bool operator== (const XRFLineRate&) const;
  inline bool operator!= (const XRFLineRate&) const;
  inline bool operator< (const XRFLineRate&) const;
};

class DetectorHardware {
public:

  /**
   * @brief
   * @param distance in cm
   */
  void addAirGap(double distance);

  int detectorZ; // this is usually 14
  fp_float detectorThickness; // thickness of detecotr in microns
  int windowZ; // front window material
  fp_float windowThickness; // thickness of front window in microns
  fp_float measuredFWHMEnergy; // gaussian width at measured energy
  fp_float measuredFWHM; // FWHM of gaussian at measured energy

  fp_float getGaussianWidthAtEnergy(fp_float keV) const;
  fp_float getDetectorEfficiencyFactor(fp_float keV) const;

};


fp_float comptonScatterEnergy(const Angle& totalAngle, fp_float KeV);
fp_float comptonScatterCoefficient(const Compound& chem, fp_float energyKeV);
fp_float rayleahScatterCoefficient(const Compound& compound, fp_float energyKeV);
fp_float comptonScatterCoefficient(const Compound& chem, const Angle& incidence, const Angle& takeoff, fp_float energyKeV);
fp_float comptonScatterEnergyDelta(const Angle& totalAngle);


fp_float lineSensitivity(const XRFLine& line);


/////////////////// Implementation of inline functions ////////////////////////////


inline Angle Angle::operator+ (const Angle& o) const {
  Angle retval;
  retval.mRadians = mRadians + o.mRadians;
  return retval;
}

inline Angle::operator fp_float() const {
  return mRadians;
}

inline fp_float Angle::getRadians() const {
  return mRadians;
}

inline Element::Element()
  : mAtomicNum(-1) {}

inline Element::Element(int Z)
  : mAtomicNum(Z) {}

inline int Element::atomicNum() const {
  return mAtomicNum;
}

inline bool Element::operator< (const Element& o) const {
  return mAtomicNum < o.mAtomicNum;
}

inline bool Element::operator== (const Element& o) const {
  return mAtomicNum == o.mAtomicNum;
}

inline bool Element::operator!= (const Element& o) const {
  return !(*this == o);
}

inline Element::operator int() const {
  return mAtomicNum;
}

inline const Element& ElementChemistry::element() const {
  return mElement;
}

inline bool ElementChemistry::operator< (const ElementChemistry& o) const {
  return mElement < o.mElement;
}

inline std::set<ElementChemistry>::const_iterator Compound::begin() const {
  return mChemValues.begin();
}

inline std::set<ElementChemistry>::const_iterator Compound::end() const {
  return mChemValues.end();
}

inline XRFLineRate::XRFLineRate(const XRFLine& l, fp_float rate, fp_float rateErr )
  : line(l), rate(rate), rateErr(rateErr) {}

inline bool XRFLineRate::operator== (const XRFLineRate& o) const {
  return line == o.line;
}

inline bool XRFLineRate::operator!= (const XRFLineRate& o) const {
  return line != o.line;
}

inline bool XRFLineRate::operator< (const XRFLineRate& o) const {
  return line < o.line;
}

} // namespace fastfp


#endif // FASTFP_COMMON_H
