#ifndef FASTFP_OPTIMIZATIONPROBLEM_H
#define FASTFP_OPTIMIZATIONPROBLEM_H


#include <Eigen/Eigen>

namespace fastfp {

class OptimizationProblem {
public:
  class Model {
  public:
    virtual ~Model() {}
    virtual int numParams() const = 0;
    virtual void setParams(const Eigen::VectorXf& params) = 0;
    virtual float value(float x) const = 0;
    virtual void gradient(float x, Eigen::VectorXf& values) const = 0;
  };

  OptimizationProblem(const sp<Model>& model, size_t numPoints);
  void solve(size_t numIterations, const std::vector<float>& x, const std::vector<float>& y);
  void setStepFactor(float);

  Eigen::VectorXf& currentPoint();
  const Eigen::VectorXf& residuals() const;

  size_t getNumPoints() const {
    return mNumPoints;
  }

private:
  const sp<Model> mModel;
  const size_t mNumPoints;
  const size_t mNumParams;
  Eigen::VectorXf mResiduals;
  Eigen::VectorXf mGradientRow;
  Eigen::MatrixXf mJacobian;
  Eigen::VectorXf mCurrentPoint;
  float mStepFactor;

};

} // namespace fastfp

#endif // FASTFP_OPTIMIZATIONPROBLEM_H
