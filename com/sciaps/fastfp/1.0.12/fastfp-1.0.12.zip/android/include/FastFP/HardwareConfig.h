#ifndef FASTFP_HARDWARECONFIG_H
#define FASTFP_HARDWARECONFIG_H

#include <json/json.h>


namespace fastfp {

class HardwareConfig {
public:
  class Condition {
  public:
    DetectorHardware mDetectorHardware;
    TubeHardware mTubeHardware;
    fp_float mTubeVoltage;
    std::vector<Filter> mTubeFilters;
    fp_float mTakeoffAngle;
    fp_float mIncidenceAngle;

  };

  static status_t readDetectorHardware(const Json::Value&, DetectorHardware&);
  static status_t readTubeHardware(const Json::Value&, TubeHardware&);
  static status_t readFilter(const Json::Value&, Filter&);


};

} // namespace fastfp

#endif // FASTFP_HARDWARECONFIG_H
