#ifndef FASTFP_SPECTRUM_H
#define FASTFP_SPECTRUM_H

namespace fastfp {

template<typename FT>
class SpectrumBase {
public:
  virtual ~SpectrumBase() {};
  virtual size_t size() const = 0;
  virtual FT valueAt(size_t index) const = 0;
  virtual void setValueAt(size_t index, FT value) = 0;
  virtual FT energyAt(size_t index) const = 0;

  const FT operator[](size_t index) const {
    return valueAt(index);
  }

};

typedef SpectrumBase<fp_float> Spectrum;

template<typename FT>
class LinearSpectrum : public SpectrumBase<FT> {
public:
  LinearSpectrum();
  LinearSpectrum(const LinearSpectrum&);
  LinearSpectrum(FT min, FT max, FT stepSize);
  LinearSpectrum(FT offset, FT slope, const std::vector<FT>& data);
  ~LinearSpectrum();

  LinearSpectrum& operator= (const LinearSpectrum& o);
  LinearSpectrum operator/ (double);

  size_t size() const;
  FT valueAt(size_t index) const;
  void setValueAt(size_t index, FT value);
  FT energyAt(size_t index) const;

  FT& operator[](size_t index);
  FT getStepSize();

  FT offset() const {
    return mOffset;
  }

  FT slope() const {
    return mSlope;
  }

private:
  FT mOffset;
  FT mSlope;
  SharedBuffer* mSharedBuffer;
};

typedef LinearSpectrum<fp_float> LSpectrum;

template<typename FT>
class DiscreteSpectrum : public SpectrumBase<FT> {
public:
  DiscreteSpectrum();
  DiscreteSpectrum(const DiscreteSpectrum&);
  DiscreteSpectrum(size_t arraySize);
  ~DiscreteSpectrum();

  DiscreteSpectrum& operator= (const DiscreteSpectrum& o);

  size_t size() const;
  FT valueAt(size_t index) const;
  void setValueAt(size_t index, FT value);
  FT energyAt(size_t index) const;
  void setEnergyAt(size_t index, FT value);

private:
  SharedBuffer* mSharedBuffer;

};

typedef DiscreteSpectrum<fp_float> DSpectrum;


sp<Spectrum> spectrumConcat(sp<Spectrum>& a, sp<Spectrum>& b);

} //namespace fastfp


#endif // FASTFP_CONFIG_H
