#ifndef FASTFP_ITERATORS_H
#define FASTFP_ITERATORS_H

namespace fastfp {

template<class Derived>
class range_view {
public:
  typedef Derived derived;

  derived& begin() const;
  derived& end() const;
};


template<
  class T,
  class Derived = typename std::vector<T>::iterator
  >
class vector_view : public range_view< Derived > {
public:
  vector_view(const Derived& begin, const Derived& end)
    : mBegin(begin), mEnd(end) {}

  vector_view(std::vector<T>& v)
    : mBegin(v.begin()), mEnd(v.end()) {}

  const Derived& begin() const {
    return mBegin;
  }

  const Derived& end() const {
    return mEnd;
  }

private:
  Derived mBegin;
  Derived mEnd;
};



} // namespace fastfp


#endif // FASTFP_ITERATORS_H
